/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author cristiane
 */
public class Juridica extends Cliente{
    private String cnpj;

    public Juridica(String cnpj, int id, String nome, String logradouro, int numero, String complemento, String bairro, String municipio, String estado, String telefone, ArrayList<Animal> animal) {
        super(id, nome, logradouro, numero, complemento, bairro, municipio, estado, telefone, animal);
        this.cnpj = cnpj;
    }

    public Juridica() {
       
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }
    
}
