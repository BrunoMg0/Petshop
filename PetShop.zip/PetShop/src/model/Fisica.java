/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author cristiane
 */
public class Fisica extends Cliente{
    private String cpf;

    public Fisica(String cpf, int id, String nome, String logradouro, int numero, String complemento, String bairro, String municipio, String estado, String telefone, ArrayList<Animal> animal) {
        super(id, nome, logradouro, numero, complemento, bairro, municipio, estado, telefone, animal);
        this.cpf = cpf;
    }

   
 

    public Fisica() {
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cnpj) {
        this.cpf = cnpj;
    }
    
}
