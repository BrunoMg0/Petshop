package controller;

import java.util.ArrayList;
import model.Conta;
import model.Item;
import modelDAO.ContaDAO;

public class GerenciaContas {

    ContaDAO cdao;

    public GerenciaContas() {
        cdao = new ContaDAO();
    }

    public void adicionarConta(Conta conta, String op) {
        cdao.incluir(conta, op);
    }

    public ArrayList<Conta> retornarContasporNome(String nome) {
        ArrayList<Conta> contas;
        contas = cdao.retornaContasPorNome(nome);
        return contas;
    }

    public ArrayList<Conta> retornarContasporData(String data) {
        ArrayList<Conta> contas;
        contas = cdao.retornaContasPorData(data);
        return contas;
    }

    public void excluirConta(int id) {
        cdao.excluirConta(id);
    }

    public ArrayList<Item> retornaItensDaConta(int id) {
        ArrayList<Item> itens;
        itens = cdao.retornaItensDaConta(id);
        return itens;
    }

    public void MudaStatusAgendamentoParaPago(int idCli) {
        cdao.mudarStatusAgendamentoPago(idCli);
    }
    
    public ArrayList<Integer> retornaidServicosPorCliente(int idCliente){
        ArrayList<Integer> idServicos = cdao.retornaidServicosPorCliente(idCliente);
        return idServicos;
    }

}
