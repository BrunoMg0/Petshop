///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
// package modelDAO;
//
//import controller.Conexao;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.time.LocalDate;
//import java.time.format.DateTimeFormatter;
//import java.util.ArrayList;
//import javax.swing.JOptionPane;
//import model.Animal;
//
//public class AnimalDAO {
//
//    private Connection conn = null;
//    DateTimeFormatter fdata = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//
//    public void AnimalDAO() {
//
//        Conexao a = Conexao.obterInstancia();
//        conn = a.obterConexao();
//
//    }
//
//    public void incluir(Animal ani) {
//        String sql;
//        PreparedStatement ps = null;
//        sql = "INSERT INTO animal(id,nome,data_nascimento,raca,altura,foto) VALUES (?,?,?,?,?,?)";
//        try {
//            ps = conn.prepareStatement(sql);
//            ps.setInt(1, ani.getId());
//            ps.setString(2, ani.getNome());
//            ps.setString(3, ani.getDataNascimento().toString());
//            ps.setString(4, ani.getRaca());
////            ps.setDouble(5, ani.getAltura());
//            ps.setBytes(6, ani.getFoto());
//            ps.execute();
//            ps.close();
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "Erro na operação de incluir registro: " + e.getMessage());
//        }
//    }
//
//    public void alterar(Animal a) {
//
//        String sql;
//        PreparedStatement ps = null;
//        sql = "update animal set nome = ?, dataNascimento = ?, raca = ?, peso = ?, altura = ?, foto = ? where id = ?";
//        try {
//            ps = conn.prepareStatement(sql);
//            ps.setString(1, a.getNome());
//            ps.setString(2, a.getDataNascimento().format(fdata));
//            ps.setString(3, a.getRaca());
//            ps.setFloat(4, a.getPeso());
//            ps.setFloat(5, a.getAltura());
//            ps.setBytes(6, a.getFoto());
//            ps.execute();
//            ps.close();
//        } catch (SQLException e) {
//            JOptionPane.showMessageDialog(null, "Erro na operação de alterar produto: " + e.getMessage());
//        }
//    }
//
//    public void excluir(int id) {
//        String sql;
//        PreparedStatement ps = null;
//        sql = "delete from animal where id = ?";
//
//        try {
//            ps = conn.prepareStatement(sql);
//            ps.setInt(1, id);
//            ps.execute();
//            ps.close();
//        } catch (Exception e) {
//            System.out.println("Erro na operação de apagar registro: " + e.getMessage());
//        }
//    }
//    public ArrayList<Animal> retornaAnimalChaveEStrangeira(){
//        return null;
//       
//        
//    }
//    public Animal retornaAnimal(int id) {
//         String sql;
//         PreparedStatement ps = null;
//         ResultSet rs = null;
//         Animal a = new Animal();
//         sql = "SELECT * FROM animal where id = ?";
//         
//         try{
//             ps = conn.prepareStatement(sql);
//             ps.setInt(1, id);
//             rs = ps.executeQuery();
//             
//             if(rs.next()){
//                 a.setId(rs.getInt("id"));
//                 a.setNome(rs.getString("nome"));
//                 a.setDataNascimento( LocalDate.parse(rs.getString("dataNascimento"), formatter));
//                 a.setRaca(rs.getString("raca"));
//                 a.setPeso(rs.getFloat("peso"));
//                 a.setAltura(rs.getByte("foto"));
//                
//                           
//             }
//             
//             ps.close();
//             
//         }catch (Exception e){
//             System.out.println("Erro na operação de listar" +e.getMessage());
//         }
//   
//        return a;      
//    }
//    
//    
//    
//
//}
//
//
//
