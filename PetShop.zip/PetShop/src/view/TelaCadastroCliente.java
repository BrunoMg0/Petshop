/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

import model.Animal;
import model.Cliente;

import model.Fisica;
import model.Juridica;

import modelDAO.ClienteDAO;

public class TelaCadastroCliente extends javax.swing.JFrame {

    //private Animal animal = new Animal();
    //private ArrayList<Animal> animais = new ArrayList<Animal>();
    private ClienteDAO cliDAO = new ClienteDAO();
    private Fisica cliF;
    private Juridica cliJ;

    //private AnimalDAO ani = new AnimalDAO();
    public TelaCadastroCliente() {
        initComponents();
    }
//    public void cadastrarCliente() {
//        int id;
//        String op;
//
//        Animal idAnimal;
//        if (!tfdNome.getText().isEmpty()) {
//
//            if (!tfdLogradouro.getText().isEmpty()) {
//                if (!tfdComplemeto.getText().isEmpty()) {
//                    if (!tfdNumero.getText().isEmpty()) {
//                        if (!tfdMunicipio.getText().isEmpty()) {
//                            if (!tfdTelefone.getText().isEmpty()) {
//                                if (!jComboBoxEstado.getItemAt(jComboBoxEstado.getSelectedIndex()).equals("- Selecione -")) {
//                                    if (!jComboBoxTipoCliente.getItemAt(jComboBoxTipoCliente.getSelectedIndex()).equals("- Selecione -")) {
//                                        op = (String) jComboBoxTipoCliente.getSelectedItem();
//                                        if ("Fisica".equals(op)) {
//
//                                            if (cliF instanceof ClienteFisica) {
//                                                id = cliDAO.proximoCodigo(cliF);
//                                                cliF = new ClienteFisica(jComboBoxTipoCliente.getItemAt(jComboBoxTipoCliente.getSelectedIndex()), id, tfdNome.getText(), tfdLogradouro.getText(),
//                                                        Integer.parseInt(tfdNumero.getText()), tfdComplemeto.getText(),
//                                                        tfdBairro.getText(), tfdMunicipio.getText(), jComboBoxEstado.getItemAt(jComboBoxEstado.getSelectedIndex()),
//                                                        tfdTelefone.getText(), null);
//                                                cliDAO.incluir(cliF);
//                                            }
//
//                                        } else {
//                                            id = cliDAO.proximoCodigo(cliJ);
//                                            cliJ = new ClienteJuridica(jComboBoxTipoCliente.getItemAt(jComboBoxTipoCliente.getSelectedIndex()), id, tfdNome.getText(), tfdLogradouro.getText(),
//                                                    Integer.parseInt(tfdNumero.getText()), tfdComplemeto.getText(),
//                                                    tfdBairro.getText(), tfdMunicipio.getText(), jComboBoxEstado.getItemAt(jComboBoxEstado.getSelectedIndex()),
//                                                    tfdTelefone.getText(),
//                                                    null);
//                                            cliDAO.incluir(cliJ);
//                                        }
//                                    } else {
//                                        JOptionPane.showMessageDialog(this, " Selecione o tipo de Cliente. Campo obrigatório");
//                                    }
//
//                                } else {
//                                    JOptionPane.showMessageDialog(this, " Selecione o estado. Campo obrigatório");
//                                }
//                            } else {
//                                JOptionPane.showMessageDialog(this, "Digite o telefone. Campo Obrigatório!!");
//                            }
//                        } else {
//                            JOptionPane.showMessageDialog(this, "Digite o município. Campo Obrigatório!!");
//                        }
//                    } else {
//                        JOptionPane.showMessageDialog(this, "Digite o número. Campo Obrigatório!!");
//                    }
//                } else {
//                    JOptionPane.showMessageDialog(this, "Digite o complemento. Campo Obrigatório");
//                }
//            } else {
//                JOptionPane.showMessageDialog(this, "Digite o complemento. Campo Obrigatório");
//            }
//        } else {
//            JOptionPane.showMessageDialog(this, "Digite o nome. Campo Obrigatório");
//        }
//        int opcao = JOptionPane.showConfirmDialog(rootPane, "Deseja adicionar um animal ?");
//        if (JOptionPane.YES_OPTION == opcao) {
//            //chamar tela de cadastro de animal
//            TelaCadastroAnimal abre = new TelaCadastroAnimal(new java.awt.Frame(), true);
//            abre.setLocationRelativeTo(null);
//            abre.setVisible(true);
//        } else {
//            JOptionPane.showMessageDialog(this, "Cliente sem animal!!");
//        }
//    }
    

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        lbnTitulo = new javax.swing.JLabel();
        lbnDigiteDados = new javax.swing.JLabel();
        lbnNome = new javax.swing.JLabel();
        tfdNome = new javax.swing.JTextField();
        tfdLogradouro = new javax.swing.JTextField();
        lbnLogradouro = new javax.swing.JLabel();
        lbnNumero = new javax.swing.JLabel();
        tfdNumero = new javax.swing.JTextField();
        tfdComplemeto = new javax.swing.JTextField();
        lbnComplemento = new javax.swing.JLabel();
        lbnBairro = new javax.swing.JLabel();
        tfdBairro = new javax.swing.JTextField();
        lbnMunicipio = new javax.swing.JLabel();
        tfdMunicipio = new javax.swing.JTextField();
        tfdTelefone = new javax.swing.JTextField();
        lbnTelefone = new javax.swing.JLabel();
        jButtonSalvar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        lbnEstado = new javax.swing.JLabel();
        jComboBoxEstado = new javax.swing.JComboBox<>();
        jComboBoxTipoCliente = new javax.swing.JComboBox<>();
        jLabelTipodeCliente = new javax.swing.JLabel();
        lbnFundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbnTitulo.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        lbnTitulo.setText("Cadastro de Cliente");
        getContentPane().add(lbnTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 40, -1, -1));

        lbnDigiteDados.setFont(new java.awt.Font("Dialog", 3, 14)); // NOI18N
        lbnDigiteDados.setText("Digite os dados do cliente");
        getContentPane().add(lbnDigiteDados, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 90, 240, 30));

        lbnNome.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        lbnNome.setText("Nome: ");
        getContentPane().add(lbnNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 80, -1));
        getContentPane().add(tfdNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 160, 370, 30));
        getContentPane().add(tfdLogradouro, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 200, 370, 30));

        lbnLogradouro.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        lbnLogradouro.setText("Logradouro:");
        getContentPane().add(lbnLogradouro, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 120, 30));

        lbnNumero.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        lbnNumero.setText("Nº");
        getContentPane().add(lbnNumero, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 250, -1, 20));
        getContentPane().add(tfdNumero, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 250, 70, 30));
        getContentPane().add(tfdComplemeto, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 250, 240, 30));

        lbnComplemento.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        lbnComplemento.setText("Complemento:");
        getContentPane().add(lbnComplemento, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, -1, -1));

        lbnBairro.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        lbnBairro.setText("Bairro: ");
        getContentPane().add(lbnBairro, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 110, 20));
        getContentPane().add(tfdBairro, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 300, 370, 30));

        lbnMunicipio.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        lbnMunicipio.setText("Município:");
        getContentPane().add(lbnMunicipio, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 110, 30));

        tfdMunicipio.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(tfdMunicipio, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 340, 370, 30));
        getContentPane().add(tfdTelefone, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 380, 250, 30));

        lbnTelefone.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        lbnTelefone.setText("Telefone:");
        getContentPane().add(lbnTelefone, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 380, 110, 20));

        jButtonSalvar.setFont(new java.awt.Font("Dialog", 3, 15)); // NOI18N
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.setBorder(new javax.swing.border.MatteBorder(null));
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSalvar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 470, 120, 40));

        jButtonCancelar.setFont(new java.awt.Font("Dialog", 3, 15)); // NOI18N
        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.setBorder(new javax.swing.border.MatteBorder(null));
        getContentPane().add(jButtonCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 470, 110, 40));

        lbnEstado.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        lbnEstado.setText("Estado:");
        getContentPane().add(lbnEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 420, 80, -1));

        jComboBoxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Selecione -", "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" }));
        getContentPane().add(jComboBoxEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 420, 150, 30));

        jComboBoxTipoCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-Selecione-", "Fisica", "jurídica" }));
        getContentPane().add(jComboBoxTipoCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 150, -1, -1));

        jLabelTipodeCliente.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        jLabelTipodeCliente.setText("Tipo Cliente");
        getContentPane().add(jLabelTipodeCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 120, -1, -1));

        lbnFundo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/fundo0.jpg"))); // NOI18N
        getContentPane().add(lbnFundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(-40, 0, 860, 540));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed

//        cadastrarCliente();
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastroCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox<String> jComboBoxEstado;
    private javax.swing.JComboBox<String> jComboBoxTipoCliente;
    private javax.swing.JLabel jLabelTipodeCliente;
    private javax.swing.JLabel lbnBairro;
    private javax.swing.JLabel lbnComplemento;
    private javax.swing.JLabel lbnDigiteDados;
    private javax.swing.JLabel lbnEstado;
    private javax.swing.JLabel lbnFundo;
    private javax.swing.JLabel lbnLogradouro;
    private javax.swing.JLabel lbnMunicipio;
    private javax.swing.JLabel lbnNome;
    private javax.swing.JLabel lbnNumero;
    private javax.swing.JLabel lbnTelefone;
    private javax.swing.JLabel lbnTitulo;
    private javax.swing.JTextField tfdBairro;
    private javax.swing.JTextField tfdComplemeto;
    private javax.swing.JTextField tfdLogradouro;
    private javax.swing.JTextField tfdMunicipio;
    private javax.swing.JTextField tfdNome;
    private javax.swing.JTextField tfdNumero;
    private javax.swing.JTextField tfdTelefone;
    // End of variables declaration//GEN-END:variables
}
